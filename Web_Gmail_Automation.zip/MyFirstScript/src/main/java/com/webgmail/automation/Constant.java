package com.webgmail.automation;

public class Constant {

    public static final String url = "https://accounts.google.com/signin";
    public static final String username ="selenium.chandni@gmail.com";
    public static final String password = "password@123";



}
